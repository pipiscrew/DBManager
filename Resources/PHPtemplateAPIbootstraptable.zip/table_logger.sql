CREATE TABLE `logger` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `entity` varchar(50) DEFAULT NULL,
  `action` varchar(50) DEFAULT NULL,
  `error` tinyint(3) unsigned DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `date_rec` datetime DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
