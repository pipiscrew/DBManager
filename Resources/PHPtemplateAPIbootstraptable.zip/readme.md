# the following feature works only on MYSQL  


when the ```TABLE B``` has FKEY to ```TABLE A``` aka :
```sql
  CONSTRAINT `leagueID` FOREIGN KEY (`league_id`) REFERENCES `leagues` (`id`)
```

the code generated for ```TABLE A``` (ex **leagues**), will appear with **expandable** rows....  

## if the user doesn't like to have expandable rows

has to remove the following :   

* the HTML5 attribute by (```pages/leagues.php```) the table HTML  :
```js
data-detail-view="true"
```

* on helper file (```entities/leagueshelper.php```) the :
  * case ``GetRecordDetailsLeaguesJS``
  * function ```GetRecordDetailsLeaguesJS()```
  * on ```GetVendorRecords()``` remove the two last parameters of ```GetVendorData2DB``` call  (```, null, 'LeaguesAfterBaseRecordInsert'```)

  * function ```LeaguesAfterBaseRecordInsert($db, $baseTableID, $data)```

-------  

complete 'TABLE B' script :

```sql
CREATE TABLE `leagueseasons` (
  `id` int(5) unsigned NOT NULL AUTO_INCREMENT,
  `league_id` int(11) unsigned NOT NULL DEFAULT 0,
  `year` varchar(4) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `leagueID` (`league_id`),
  CONSTRAINT `leagueID` FOREIGN KEY (`league_id`) REFERENCES `leagues` (`id`)
) ENGINE=InnoDB CHARSET=utf8 COLLATE=utf8_unicode_ci;
```

-------  

if more than one table referring the ```TABLE A```, only the first will be processed