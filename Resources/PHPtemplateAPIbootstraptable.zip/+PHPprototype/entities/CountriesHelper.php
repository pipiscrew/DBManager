<?php

require_once '../vendor/general.php';
require_once '../vendor/VendorGetter.php';

if (!isset($_POST['action'])){
	ReportJS(1, 'No valid parameter!');
	exit;
}

////////////////ACTIONS
$action = $_POST['action'];

switch ($action) {
	case 'GetVendorCountriesJS' :
		GetVendorCountriesJS();
		break;
	case 'GetVendorCountriesCRON' :
		//todo
		break;
	case 'FillGrid' :
		FillGrid();
		break;
	default :
		ReportJS(2, 'No action defined!');
		exit;
}

//FrontEnd - exports response for JS
function GetVendorCountriesJS()
{
	$result = GetVendorRecords();

	ReportJS($result[0], $result[1]);
}

//unique for JS & CRON
function GetVendorRecords(){

	//key = dbase field, array = object direction to JSON field
    $insertArr = array(
        'title' => array('name'),
        'code' => array('code'),
        'flag' => array('flag')
    );

	//object direction to JSON field
    $validationArr = array(
        	array('name'),
			array('code')
    );

	return GetVendorData2DB('https://xxxx.io/countries', 
					'Country',
					'INSERT INTO `countries` (title, code, flag) VALUES (:title, :code, :flag)',
					$insertArr, $validationArr, 1);
}


function FillGrid(){

		FillGridRows(array(
								'id',
								'title',
								'code',    
								'flag'
							), 
		'select title, code, flag from countries',
		'select count(id) from countries', true);

}


?>