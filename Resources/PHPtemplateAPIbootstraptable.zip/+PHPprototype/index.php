<?php 
  $tabs = array();

  $files = array_filter(glob('pages/*.php'), 'is_file');
  foreach ($files as $file) {
    
	if (substr($file, 6, 2) == 0) //accept only filenames starting with numbers
      continue;
	  
    $tabs[] = array( 'name' => ucwords(substr($file, 8, (strlen($file) - (4+8)))), 'file' => $file );
  }

  if (!$tabs)
    die("Fatal error no tabs found!");
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>PipisCrew</title>

	<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">

	<link rel="stylesheet" href="assets/bootstrap.min.css">
  <link rel="stylesheet" href="assets/bootstrap-table.min.css">
  <link rel="stylesheet" href="assets/fontawessome.css">
  
	<script src="assets/jquery.min.js"></script>
	<script src="assets/bootstrap.bundle.min.js"></script> <!-- bootstrap.min.js OR bundle.min.js -->
  <script src="assets/bootstrap-table.min.js"></script>
  
  
</head>
<body>

  <!-- TABS [START] -->
  <ul class="nav nav-tabs" role="tablist">

    <?php

      $active = ' active';

      foreach ($tabs as $tab) {
        $entity = $tab['name'];
        $li =  <<<EOT
        <li class="nav-item">
          <button class="nav-link{$active}" data-bs-toggle="tab" onclick="RefreshGrid{$tab['name']}()" data-bs-target="#{$tab['name']}" type="button" role="tab">{$tab['name']}</button>
        </li>\n
        EOT;
        $active = '';
        echo $li;
      }
    ?>

  </ul>
  <!-- TABS [END] -->


  <!-- TABS Content [START] -->
  <div id="tabsContent" class="tab-content">

    <?php

      $active = ' show active';

      foreach ($tabs as $tab) {
        $entity = $tab['name'];
        echo "<div class=\"tab-pane fade{$active}\" role=\"tabpanel\" id=\"{$entity}\">\n";
        include ("{$tab['file']}");
        echo "\n</div>\n";
        
        $active = '';
      }
    ?>
    
  </div>
  <!-- TABS Content [END] -->

</body>
</html>