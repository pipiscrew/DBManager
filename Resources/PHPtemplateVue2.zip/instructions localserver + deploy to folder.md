## instructions
-----  
### proxy  
for development purposes, to have simultaneously the 
* Node development server
* Apache  

talking together, aka **Vue calls** going to **Apache server**. Vue has a **proxy** feature, by declaring it to `vue.config.js` (is near `package.json`).  So here we have said, any call made to **api path** redirect it to **localhost** (80).
```ts
module.exports = {
  devServer: {
    proxy: {
      '^/api': {
        target: 'http://localhost',
      }
    }
  }
}
```
with this configuration if Vue asks `'api/test.php'`, will go to `http://localhost:80/api/test.php`.  

**Not working** with PHP debug server `php.exe -S localhost:80 -t ../htdocs/` needs apache / nginx, the latter is not tested.  

&nbsp;  
### deploy to real server, sub folder  
Most of the times, on server, uploading the compiled project to a **subfolder**. This subfolder has to be declared to `.env.production`, underneath this variable used at :
* router.js - `base: process.env.VUE_APP_BASE_URL`  
* vue.config.js - `publicPath: process.env.VUE_APP_BASE_URL`

attention when you adjusting the **.env files** most possible is when you going for **build** or **serve**, you end up with an error :  
```js
\router.js - 30:9  error  'process' is not defined  no-undef
```

the **workaround** is to close the DOS window, reopen it, re execute the same command, no erorrs will appear.

the **permanent fix** is to use `vue-cli-service build --mode production`  

&nbsp;  
### use sub folder for API

The solution is to **hardcode** the host, on the following files,  

`.env`  
`.env.production`  

should add the a new **key** example `VUE_APP_ROOT_API`  

```ts
//FOR DEBUG (.env)
VUE_APP_BASE_URL=/
VUE_APP_ROOT_API=http://localhost:8080/

//FOR PROD (.env.production)
VUE_APP_BASE_URL=/vas/
VUE_APP_ROOT_API=http://domain.com/vas/
```

the above configuration instract :  
* when **debug** to use the **htdocs** (proxy to localhost will continue work)   
* when **PROD** to use folder **vas**  

then on Vue files all **API calls** should be adjusted from  

```ts
GetData("/api/xxxxAPI.php", formData);
```

to 

```ts
GetData(process.env.VUE_APP_ROOT_API + "api/xxxxAPI.php", formData);
```



&nbsp;  

-----  

&nbsp;  

# PHP Session expiration setup

The configuration primarly should be done on php.ini, we can use `ini_set` function to set it on runtime.

```php
<?php

//prior v7
//https://stackoverflow.com/a/24350918/1320686
ini_set('session.cookie_lifetime', 86400);
ini_set('session.gc_maxlifetime', 86400);

sesion_start(); //https://www.php.net/manual/en/function.session-start.php


//v7 and later
//https://stackoverflow.com/a/53485125/1320686
session_start([
    'cookie_lifetime' => 86400,
    'gc_maxlifetime' => 86400
]);
```

&nbsp;  
86400 = represents 24h, value is in seconds.  
&nbsp;  
[session.cookie_lifetime](https://www.php.net/manual/en/session.configuration.php#ini.session.cookie-lifetime) specifies the lifetime of the cookie in seconds which is sent to the browser.  

&nbsp;  
[session.gc_maxlifetime](https://www.php.net/manual/en/session.configuration.php#ini.session.gc-maxlifetime) specifies the number of seconds after which data will be seen as 'garbage' and potentially cleaned up. Garbage collection may occur during session start  
