# the following feature works only on MYSQL  


when the ```TABLE B``` has FKEY to ```TABLE A``` aka :
```sql
  CONSTRAINT `leagueID` FOREIGN KEY (`league_id`) REFERENCES `leagues` (`id`)
```

the code generated for ```TABLE A``` (ex **leagues**), will appear with **expandable** rows....  

## if the user doesn't like to have expandable rows

has to remove the following :   

* the `<template v-slot:expanded-item` `slot` exist into `v-data-table` tag, and the `EXPAND FUNCTIONS` in the end of the `entity.vue` file.
* on `entityAPI.php` the action and the function `GetRecordDetailsEnitity` 

-------  

complete 'TABLE B' script :

```sql
CREATE TABLE `leagueseasons` (
  `id` int(5) unsigned NOT NULL AUTO_INCREMENT,
  `league_id` int(11) unsigned NOT NULL DEFAULT 0,
  `year` varchar(4) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `leagueID` (`league_id`),
  CONSTRAINT `leagueID` FOREIGN KEY (`league_id`) REFERENCES `leagues` (`id`)
) ENGINE=InnoDB CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
```

-------  

if more than one table referring the ```TABLE A```, a form will be shown, to select which one will be expandable.  

-------  

script to create FK, to existing table
```sql
ALTER TABLE `TABLE1` 
--if needed to create a new column ADD COLUMN `FK_COLUMN` INT NOT NULL DEFAULT(1),
ADD CONSTRAINT `FK_TABLE2_COLUMN` FOREIGN KEY (`FK_COLUMN`) 
REFERENCES `TABLE2`(`PK_COLUMN`);

--**`TABLE1.FK_COLUMN` must have values existing to `TABLE2.PK_COLUMN`

--if you get error, make sure are same
SHOW CREATE TABLE table1
SHOW CREATE TABLE table2
```