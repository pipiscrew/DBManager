* by default when `FK`, application creates this function to API, the glitch is the `title` field, user must fix it  
```php
function GetRecordsEntityFK(){

    $db = new dbase();
    $db->connect_mysql();

    //echo json_encode( $db->getSet("select id,title from Categories", null));
    echo json_encode( $db->getSet("select id,categoryName from Categories", null));
}
```


* on `EntityDetail.vue`, user has to fix the `item-text` property with the `field name` setted to `function GetRecordsEntityFK()`  

```js
              <v-autocomplete
                v-model="privateRecord.category_id"
                :items="category_idItems"
                :rules="[() => !!privateRecord.category_id || 'This field is required']"
                //item-text="title"
                item-text="categoryName"
                item-value="id"
```


* at function `FillGridEntity()`

when join made, is **possible** the main table ID, to conflict with joined table ID, workaround :
```sql
SELECT Entity.id as id,
```

on the same function the selection of the `FK text` again is setted as `title`, user must fix it.