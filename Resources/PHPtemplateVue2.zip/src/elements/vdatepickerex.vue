<template>
  <v-menu
    ref="menu"
    v-model="menu"
    :close-on-content-click="false"
    transition="scale-transition"
    offset-y
    min-width="auto"
  >
    <template v-slot:activator="{ on, attrs }">
      <v-text-field
        :rules="rule"
        :value="formatDate"
        :label="caption"
        readonly
        v-bind="attrs"
        v-on="on"
      ></v-text-field>
    </template>
    <v-date-picker
      :value="value"
      @input="
        menu = false;
        $emit('update:value', $event);
      "
      locale="el"
    ></v-date-picker>
  </v-menu>
</template>

<script>
export default {
  mounted: function () {
    if (!this.required) this.rule = [];

    if (!this.required && this.setTodayWhenNew) {
      //when edit, after, will overwrite this
      this.$emit("update:value", new Date().toISOString().substr(0, 10));
    }
  },
  props: {
    caption: String,
    value: String,
    required: Boolean,
    setTodayWhenNew: Boolean,
  },
  data() {
    return {
      menu: false,
      rule: [() => !!this.value || "This field is required"],
    };
  },
  computed: {
    formatDate() {
      // https://gist.github.com/wpsmith/7604842
      return this.value ? new Date(this.value).toLocaleDateString("el") : "";
    },
  },
};
</script>