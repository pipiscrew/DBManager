<template>
  <v-text-field
    :value="value"
    :label="caption"
    :rules="rule"
    @input="$emit('update:value', $event)"
  ></v-text-field>
</template>

<script>
export default {
  mounted: function () {
    if (this.dec)
      this.rule = [
        () => /^\d+(\.\d{1,2})?$/.test(this.value) || "Decimal number required",
      ];
  },
  props: {
    caption: String,
    value: [String, Number],
    dec: Boolean,
  },
  data() {
    return {
      rule: [() => /^[0-9]+$/.test(this.value) || "Number required"],
    };
  },
};
</script>