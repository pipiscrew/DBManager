<template>
<div>
  <v-row>
    <v-col
      cols="11"
      sm="5"
    >
      <v-menu
        ref="menu"
        v-model="menu"
        :close-on-content-click="false"
        transition="scale-transition"
        offset-y
        min-width="auto"
      >
        <template v-slot:activator="{ on, attrs }">
          <v-text-field
            :rules="rule"
            :value="formatDate"
            :label="caption"
            prepend-icon="mdi-calendar"
            readonly
            v-bind="attrs"
            v-on="on"
          ></v-text-field>
        </template>
        <v-date-picker
          :value="value"
          @input="
            menu = false;
            $emit('update:value', $event);
          "
          locale="el"
        ></v-date-picker>
      </v-menu>
    </v-col>
    <v-spacer></v-spacer>
    <v-col
      cols="11"
      sm="5"
    >
      <v-menu
        ref="menub"
        v-model="menu2"
        :close-on-content-click="false"
        transition="scale-transition"
        offset-y
        max-width="290px"
        min-width="290px"
      >
        <template v-slot:activator="{ on, attrs }">
          <v-text-field
            :rules="ruleTime"
            v-model="txtTime"
            :label="caption"
            prepend-icon="mdi-clock-time-four-outline"
            readonly
            v-bind="attrs"
            v-on="on"
          ></v-text-field>
        </template>
        <v-time-picker
          v-if="menu2"
          v-model="txtTime"
          full-width
          @click:minute="$refs.menub.save(txtTime)"
          format="24hr"
        ></v-time-picker>
      </v-menu>
  </v-col>
</v-row>
</div>
</template>

<script>
// https://vuetifyjs.com/en/components/time-pickers
// https://vuetifyjs.com/en/components/date-pickers
// https://github.com/Hastes/v-datetime-field
export default {
  mounted: function () {
    if (!this.required) {
       this.rule = [];
       this.ruleTime = [];
    }
 
  },
  props: {
    caption: String,
    value: String,
    required: Boolean,
  },
  data() {
    return {
      txtTime: null,
      menu: false,
      menu2: false,
      rule: [() => !!this.value || "This field is required"],
      ruleTime: [() => !!this.txtTime || "This field is required"],
      updating : false
    };
  },
  watch :{
    value: 'processEntry',
    txtTime: 'processEntry'
  },
  computed: {
    formatDate() {
      // https://gist.github.com/wpsmith/7604842
      return this.value ? new Date(this.value).toLocaleDateString("el") : "";
    },
  },
  methods : {
    processEntry(newVal){

      if (this.updating) { //avoid uneeded calls
        this.updating=false;
        return;
      }

      let v;

      if (newVal.substr(2,1) != ":") { //date updated
          if (!this.txtTime)
          {   
              this.updating = true;

              if (this.value.length > 10)
                this.txtTime = this.value.substring(11,19);
              else 
                this.txtTime = "00:00:00";
          }
          
          v = this.value.substr(0, 10) + ' ' + this.txtTime;
      }
      else {
          //time updated
          if (this.value)
            v = this.value.substr(0, 10) + ' ' + this.txtTime;
          else 
            v = new Date().toISOString().substr(0, 10) + ' ' + this.txtTime;
      }

      this.$emit("update:value", v);
    }
  }
};
</script>