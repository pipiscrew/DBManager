export default {
    // user : null,
    GetLogin,
    IsLoggedIn,
    GetData,
    SetData,
    Class2FormData,
    Class2Class,
    TypeRegulator
}


function GetLogin(url, postData) {

    const requestOptions = {
        method: "POST",
        cache: 'no-cache',
        body: postData
    };

    return fetch(url, requestOptions).then(response => {
        if (response.ok) {
            return response.json();
        }
        else
            return response.json().then(error => ({ error }));
    })
        .catch(error => {
            return { error };
        });
}


function IsLoggedIn() {

    const requestOptions = {
        method: "GET",
        cache: 'no-cache'
    };

    let url = 'api/isLoggedin.php';

    return fetch(url, requestOptions).then(response => {
        return response.json().then(function (response) {
            return response.status;
        })
            .catch(() => { return false; })
    });
}


function GetData(url, postData) {
    const requestOptions = {
        method: "POST",
        cache: "no-cache",
        body: postData,
    };

    return fetch(url, requestOptions)
        .then(response => {
            if (response.ok) {
                return response.json();
            } else return response.json().then((error) => ({ error }));
        })
        .catch((error) => {
            return { error };
        });
}



function SetData(url, postData) {
    const requestOptions = {
        method: "POST",
        cache: "no-cache",
        body: postData,
    };

    return fetch(url, requestOptions)
        .then(response => {
            if (response.ok) {
                return response.json();
            } else return response.json().then((error) => ({ error }));
        })
        .catch((error) => {
            return { error };
        });
}

function Class2FormData(action, entity) {
    //https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Statements/for...in
    let formData = new FormData();
    formData.append("action", action);

    for (const property in entity) {
        formData.append(property, entity[property]);
    }

    return formData;
}

function Class2Class(src, dest) {

    for (const property in src) {
        dest[property] = src[property];
    }

}

function TypeRegulator(obj, retType) {
    // 1 - string
    // 2 - integer
    // 3 - boolean
    // 4 - float
    // 5 - date
    // too lazy to use typescript for a typed class

    try {
        switch (retType) {
            case 1:
                return (!obj ? '' : obj);
            case 2:
                return (!obj ? 0 : parseInt(obj));
            case 3:
                return (!obj ? false : Boolean(parseInt(obj)));
            case 5:
                return (!obj ? '' : ((obj == '0000-00-00 00:00:00' || obj == '0000-00-00' ) ? '' : obj));
            default:
                return (!obj ? 0 :parseFloat(obj));
        }
    }
    catch (error) {
        alert("TypeRegulator err@ \n" + error);
    }
}

