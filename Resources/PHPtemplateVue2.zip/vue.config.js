module.exports = {
  productionSourceMap: false, 
  publicPath: process.env.VUE_APP_BASE_URL,
  devServer: {
    proxy: {
      '^/api': {
        target: 'http://localhost',
        // ws: true,
        // changeOrigin: true
      }
    }
  },
  transpileDependencies: [
    'vuetify'
  ]
}