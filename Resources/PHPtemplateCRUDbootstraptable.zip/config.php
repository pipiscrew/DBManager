<?php
function connect() {
	$mysql_hostname = "localhost";
	$mysql_user = "";
	$mysql_password = "";
	$mysql_database = "";
	
	
	$dbh = new PDO("mysql:host=$mysql_hostname;dbname=$mysql_database", $mysql_user, $mysql_password,
                    array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES 'utf8'"));
	
	return $dbh;
}

function getScalar($db, $sql, $params) {
	if ($stmt = $db -> prepare($sql)) {

		$stmt->execute($params);

		return $stmt->fetchColumn();
	} else
		return 0;
}


function getRow($db, $sql, $params) {
	if ($stmt = $db -> prepare($sql)) {

		$stmt->execute($params);

		$row = $stmt->fetchAll(PDO::FETCH_ASSOC);

		return $row[0];
	} else
		return null;
}


//http://no2.php.net/manual/en/mysqli-stmt.bind-param.php#115028
function bind_param_array( $stmt,  $types,  $vars ){
    $php_command = '$stmt->bind_param( $types';
    for( $i=0;$i<count($vars);$i++)
    {
        $php_command .= ',$vars['.$i.']';
    }
    $php_command .= ');';
    return eval( $php_command );
}

?>