					<?php
					include ('template_top.php');
					?>

				<!-- Content Header (Page header) -->
				<section class="content-header">
					<h1> Dashboard </h1>
				</section>

				<!-- Main content -->
				<section class="content">
				
					<div class="row">
						<div class="col-xs-12">
							<div class="box">
								<div class="box-body">
								
									<h4>Inspired by CRUD Admin Generator! </h4>

										<p>The advantage : no PHP framework required</p>

										<br />
										<strong>CRUD Admin Generator : </strong><a href="http://crud-admin-generator.com" target="_blank">http://crud-admin-generator.com</a>
										<br />

										<br />
										<strong>Based on FREE Bootstrap Theme : </strong><a href="http://almsaeedstudio.com/" target="_blank">http://almsaeedstudio.com/</a>
										<br />									

								</div>
							</div>
						</div>
					</div>

					<?php
					include ('template_bottom.php');
					?>