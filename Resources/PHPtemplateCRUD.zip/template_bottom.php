				</section><!-- /.content -->
			</aside><!-- /.right-side -->
		</div><!-- ./wrapper -->
		<!-- add new calendar event modal -->


		<!-- AdminLTE App -->
		<script src="js/AdminLTE/app.js" type="text/javascript"></script>

	</body>
</html>