<?php

//enable global exception handler
//include ('Debug.php');
//
////Catch
//Debug::register();


session_start();

if (isset($_POST['submit']))//If the form has been submitted
{
	include ('92nNE1WK_config.php');

	$db = connect();

	//try to find @ users table (aka admin/3rd party users)
	$r = getScalar($db, "SELECT COUNT(ID) FROM admin_users WHERE mail=? AND password=?", array($_POST['email'], $_POST['pass']));

	if ($r > 0) {
		//Login success - set session cookie
		$_SESSION['u'] = $_POST['email'];

		$r = getScalar($db, "SELECT is_sadmin FROM admin_users WHERE mail=? AND password=?", array($_POST['email'], $_POST['pass']));
		
		$_SESSION['sadmin'] = $r;
		
		//Redirect the user to a logged in page
		header("Location: portal.php");

		//Do not display any more script for this page
		exit ;
	} else
			//Redirect the user to a log in page
			header("Location: index.html");

} else
	echo "no submit";
?>